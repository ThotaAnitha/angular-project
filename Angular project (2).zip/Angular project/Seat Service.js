// seat.service.ts
import { Injectable } from '@angular/core';
import { Seat } from './seat.model';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SeatService {
  private seats: Seat[] = [];
  private seatsSubject: BehaviorSubject<Seat[]> = new BehaviorSubject<Seat[]>([]);

  constructor() {
    this.initializeSeats();
  }

  // Initialize seat data
  initializeSeats() {
    let seatId = 1;
    for (let row = 1; row <= 12; row++) {
      const seatsInRow = row === 12 ? 3 : 7;
      for (let seat = 1; seat <= seatsInRow; seat++) {
        this.seats.push({
          seatId: seatId,
          rowNumber: row,
          seatNumber: seat,
          isBooked: false
        });
        seatId++;
      }
    }

    // Pre-book some seats for demonstration
    [5, 12, 70].forEach(id => {
      const seat = this.seats.find(s => s.seatId === id);
      if (seat) seat.isBooked = true;
    });

    this.seatsSubject.next(this.seats);
  }

  // Get all seats
  getSeats() {
    return this.seatsSubject.asObservable();
  }

  // Book seats based on the required number
  bookSeats(requiredSeats: number): Seat[] | null {
    // Try to find a single row with enough consecutive seats
    for (let row = 1; row <= 12; row++) {
      const seatsInRow = this.seats.filter(s => s.rowNumber === row && !s.isBooked);
      if (seatsInRow.length >= requiredSeats) {
        // Book the first 'requiredSeats' seats in this row
        const seatsToBook = seatsInRow.slice(0, requiredSeats);
        seatsToBook.forEach(seat => seat.isBooked = true);
        this.seatsSubject.next(this.seats);
        return seatsToBook;
      }
    }

    // If not possible, book nearby seats across rows
    const availableSeats = this.seats.filter(s => !s.isBooked);
    if (availableSeats.length >= requiredSeats) {
      const seatsToBook: Seat[] = availableSeats.slice(0, requiredSeats);
      seatsToBook.forEach(seat => seat.isBooked = true);
      this.seatsSubject.next(this.seats);
      return seatsToBook;
    }

    // Not enough seats available
    return null;
  }
}
