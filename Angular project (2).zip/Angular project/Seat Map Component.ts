// seat-map.component.ts
import { Component, OnInit } from '@angular/core';
import { SeatService } from '../seat.service';
import { Seat } from '../seat.model';

@Component({
  selector: 'app-seat-map',
  templateUrl: './seat-map.component.html',
  styleUrls: ['./seat-map.component.css']
})
export class SeatMapComponent implements OnInit {
  seats: Seat[] = [];

  constructor(private seatService: SeatService) { }

  ngOnInit(): void {
    this.seatService.getSeats().subscribe(seats => {
      this.seats = seats;
    });
  }

  getRowSeats(row: number): Seat[] {
    return this.seats.filter(seat => seat.rowNumber === row);
  }
}
