// booking.component.ts
import { Component } from '@angular/core';
import { SeatService } from '../seat.service';
import { Seat } from '../seat.model';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent {
  requiredSeats: number = 1;
  bookedSeats: Seat[] | null = null;
  errorMessage: string = '';

  constructor(private seatService: SeatService) { }

  book() {
    this.bookedSeats = this.seatService.bookSeats(this.requiredSeats);
    if (!this.bookedSeats) {
      this.errorMessage = 'Not enough seats available to fulfill your request.';
    } else {
      this.errorMessage = '';
    }
  }
}
